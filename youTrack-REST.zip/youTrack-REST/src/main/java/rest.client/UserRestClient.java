package rest.client;

import java.net.URI;

public interface UserRestClient {
    User getUser(String var1, ProgressMonitor var2);

    User getUser(URI var1, ProgressMonitor var2);
}
