package rest.client;


import javax.annotation.Nullable;

public class GetCreateIssueMetadataOptions {
    public static final String EXPAND_PROJECTS_ISSUETYPES_FIELDS = "projects.issuetypes.fields";
    @Nullable
    public final Iterable<Long> projectIds;
    @Nullable
    public final Iterable<String> projectKeys;
    @Nullable
    public final Iterable<Long> issueTypeIds;
    @Nullable
    public final Iterable<String> issueTypeNames;
    @Nullable
    public final Iterable<String> expandos;

    public GetCreateIssueMetadataOptions(@Nullable Iterable<String> expandos, @Nullable Iterable<String> issueTypeNames, @Nullable Iterable<Long> issueTypeIds, @Nullable Iterable<String> projectKeys, @Nullable Iterable<Long> projectIds) {
        this.expandos = expandos;
        this.issueTypeNames = issueTypeNames;
        this.issueTypeIds = issueTypeIds;
        this.projectKeys = projectKeys;
        this.projectIds = projectIds;
    }
}
