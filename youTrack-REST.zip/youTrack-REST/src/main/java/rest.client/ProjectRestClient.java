package rest.client;

import java.net.URI;

public interface ProjectRestClient {
    Project getProject(String var1, ProgressMonitor var2);

    Project getProject(URI var1, ProgressMonitor var2);

    Iterable<BasicProject> getAllProjects(ProgressMonitor var1);
}
