package rest.client;

import java.net.URI;

public interface AddressableEntity {
    URI getSelf();
}
