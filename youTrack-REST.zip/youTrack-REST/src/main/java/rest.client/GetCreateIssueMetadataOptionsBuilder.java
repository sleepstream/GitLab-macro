package rest.client;


import com.google.common.collect.ImmutableList;
import com.google.common.collect.Sets;

public class GetCreateIssueMetadataOptionsBuilder {
    private Iterable<String> expandos = Sets.newHashSet();
    private Iterable<String> issueTypeNames;
    private Iterable<Long> issueTypeIds;
    private Iterable<String> projectKeys;
    private Iterable<Long> projectIds;

    public GetCreateIssueMetadataOptionsBuilder() {
    }

    public GetCreateIssueMetadataOptionsBuilder withExpandos(Iterable<String> expandos) {
        this.expandos = expandos;
        return this;
    }

    public GetCreateIssueMetadataOptionsBuilder withExpandos(String... expandos) {
        return this.withExpandos((Iterable)ImmutableList.copyOf(expandos));
    }

    public GetCreateIssueMetadataOptionsBuilder withExpandedIssueTypesFields() {
        return this.withExpandos((Iterable)ImmutableList.of("projects.issuetypes.fields"));
    }

    public GetCreateIssueMetadataOptionsBuilder withIssueTypeNames(Iterable<String> issueTypeNames) {
        this.issueTypeNames = issueTypeNames;
        return this;
    }

    public GetCreateIssueMetadataOptionsBuilder withIssueTypeNames(String... issueTypeNames) {
        return this.withIssueTypeNames((Iterable)ImmutableList.copyOf(issueTypeNames));
    }

    public GetCreateIssueMetadataOptionsBuilder withIssueTypeIds(Iterable<Long> issueTypeIds) {
        this.issueTypeIds = issueTypeIds;
        return this;
    }

    public GetCreateIssueMetadataOptionsBuilder withIssueTypeIds(Long... issueTypeIds) {
        return this.withIssueTypeIds((Iterable)ImmutableList.copyOf(issueTypeIds));
    }

    public GetCreateIssueMetadataOptionsBuilder withProjectKeys(Iterable<String> projectKeys) {
        this.projectKeys = projectKeys;
        return this;
    }

    public GetCreateIssueMetadataOptionsBuilder withProjectKeys(String... projectKeys) {
        return this.withProjectKeys((Iterable)ImmutableList.copyOf(projectKeys));
    }

    public GetCreateIssueMetadataOptionsBuilder withProjectIds(Iterable<Long> projectIds) {
        this.projectIds = projectIds;
        return this;
    }

    public GetCreateIssueMetadataOptionsBuilder withProjectIds(Long... projectIds) {
        return this.withProjectIds((Iterable)ImmutableList.copyOf(projectIds));
    }

    public GetCreateIssueMetadataOptions build() {
        return new GetCreateIssueMetadataOptions(this.expandos, this.issueTypeNames, this.issueTypeIds, this.projectKeys, this.projectIds);
    }
}

