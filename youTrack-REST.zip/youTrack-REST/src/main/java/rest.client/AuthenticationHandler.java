package rest.client;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.filter.Filterable;
import com.sun.jersey.client.apache.config.ApacheHttpClientConfig;

public interface AuthenticationHandler {
    void configure(ApacheHttpClientConfig var1);

    void configure(Filterable var1, Client var2);
}