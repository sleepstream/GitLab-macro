package rest.client;

import javax.annotation.Nullable;

public interface SearchRestClient {
    SearchResult searchJql(@Nullable String var1, ProgressMonitor var2);

    SearchResult searchJql(@Nullable String var1, int var2, int var3, ProgressMonitor var4);
}
