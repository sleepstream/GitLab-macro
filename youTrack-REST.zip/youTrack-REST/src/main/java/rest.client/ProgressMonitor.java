package rest.client;

public interface ProgressMonitor {
}
