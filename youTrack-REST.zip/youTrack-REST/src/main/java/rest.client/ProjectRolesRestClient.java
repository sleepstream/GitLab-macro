package rest.client;

import java.net.URI;

public interface ProjectRolesRestClient {
    ProjectRole getRole(URI var1, ProgressMonitor var2);

    ProjectRole getRole(URI var1, Long var2, ProgressMonitor var3);

    Iterable<ProjectRole> getRoles(URI var1, ProgressMonitor var2);
}
