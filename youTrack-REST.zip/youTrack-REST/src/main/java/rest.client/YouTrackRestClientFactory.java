package rest.client;

import java.net.URI;

public interface YouTrackRestClientFactory {

    YouTrackRestClient create(URI var1, AuthenticationHandler var2);

    YouTrackRestClient createWithBasicHttpAuthentication(URI var1, String var2, String var3);
}
