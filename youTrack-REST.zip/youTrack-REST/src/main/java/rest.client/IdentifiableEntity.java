package rest.client;

public interface IdentifiableEntity<T> {
    T getId();
}
