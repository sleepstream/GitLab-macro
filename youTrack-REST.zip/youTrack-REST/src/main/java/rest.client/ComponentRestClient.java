package rest.client;

import java.awt.*;
import java.net.URI;
import javax.annotation.Nullable;
import javax.swing.*;

public interface ComponentRestClient {
    Component getComponent(URI var1, ProgressMonitor var2);

    Component createComponent(String var1, ComponentInput var2, ProgressMonitor var3);

    Component updateComponent(URI var1, ComponentInput var2, ProgressMonitor var3);

    void removeComponent(URI var1, @Nullable URI var2, ProgressMonitor var3);

    int getComponentRelatedIssuesCount(URI var1, ProgressMonitor var2);
}
