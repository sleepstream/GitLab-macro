package rest.client;

import com.sun.istack.Nullable;
import java.util.Collections;
import java.util.Iterator;

public class OptionalIterable<T> implements Iterable<T> {
    private static final OptionalIterable absentInstance = new OptionalIterable((Iterable)null);
    @Nullable
    private final Iterable<T> iterable;

    public static <T> OptionalIterable<T> absent() {
        return absentInstance;
    }

    public OptionalIterable(@Nullable Iterable<T> iterable) {
        this.iterable = iterable;
    }

    public Iterator<T> iterator() {
        return this.isSupported() ? this.iterable.iterator() : Collections.emptyList().iterator();
    }

    public boolean isSupported() {
        return this.iterable != null;
    }
}