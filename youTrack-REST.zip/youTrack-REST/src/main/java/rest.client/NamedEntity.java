package rest.client;

public interface NamedEntity {
    String getName();
}
