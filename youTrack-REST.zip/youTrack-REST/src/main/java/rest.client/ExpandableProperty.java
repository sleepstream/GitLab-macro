package rest.client;

import com.google.common.base.Objects;
import java.util.Collection;
import javax.annotation.Nullable;

public class ExpandableProperty<T> {
    private final int size;
    @Nullable
    private final Collection<T> items;

    public ExpandableProperty(int size) {
        this.size = size;
        this.items = null;
    }

    public ExpandableProperty(int size, @Nullable Collection<T> items) {
        this.size = size;
        this.items = items;
    }

    public ExpandableProperty(Collection<T> items) {
        this.size = items.size();
        this.items = items;
    }

    public int getSize() {
        return this.size;
    }

    @Nullable
    public Iterable<T> getItems() {
        return this.items;
    }

    public String toString() {
        return Objects.toStringHelper(this).add("size", this.size).add("items", this.items).toString();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof ExpandableProperty)) {
            return false;
        } else {
            ExpandableProperty that = (ExpandableProperty)obj;
            return Objects.equal(this.size, that.size) && Objects.equal(this.items, that.items);
        }
    }

    public int hashCode() {
        return Objects.hashCode(new Object[]{this.size, this.items});
    }
}

