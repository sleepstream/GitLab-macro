package rest.client;

import java.net.URI;
import javax.annotation.Nullable;

public interface VersionRestClient {
    Version getVersion(URI var1, ProgressMonitor var2);

    Version createVersion(VersionInput var1, ProgressMonitor var2);

    Version updateVersion(URI var1, VersionInput var2, ProgressMonitor var3);

    void removeVersion(URI var1, @Nullable URI var2, @Nullable URI var3, ProgressMonitor var4);

    VersionRelatedIssuesCount getVersionRelatedIssuesCount(URI var1, ProgressMonitor var2);

    int getNumUnresolvedIssues(URI var1, ProgressMonitor var2);

    Version moveVersionAfter(URI var1, URI var2, ProgressMonitor var3);

    Version moveVersion(URI var1, VersionPosition var2, ProgressMonitor var3);
}