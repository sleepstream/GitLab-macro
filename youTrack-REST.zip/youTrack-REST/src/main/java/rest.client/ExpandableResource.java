package rest.client;

public interface ExpandableResource {
    Iterable<String> getExpandos();
}
