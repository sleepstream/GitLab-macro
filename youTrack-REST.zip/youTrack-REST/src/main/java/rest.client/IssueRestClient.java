package rest.client;

import java.io.File;
import java.io.InputStream;
import java.net.URI;
import javax.annotation.Nullable;

public interface IssueRestClient {
    BasicIssue createIssue(IssueInput var1, ProgressMonitor var2);

    Iterable<CimProject> getCreateIssueMetadata(@Nullable GetCreateIssueMetadataOptions var1, ProgressMonitor var2);

    Issue getIssue(String var1, ProgressMonitor var2);

    Issue getIssue(String var1, Iterable<IssueRestClient.Expandos> var2, ProgressMonitor var3);

    Watchers getWatchers(URI var1, ProgressMonitor var2);

    Votes getVotes(URI var1, ProgressMonitor var2);

    Iterable<Transition> getTransitions(URI var1, ProgressMonitor var2);

    Iterable<Transition> getTransitions(Issue var1, ProgressMonitor var2);

    void transition(URI var1, TransitionInput var2, ProgressMonitor var3);

    void transition(Issue var1, TransitionInput var2, ProgressMonitor var3);

    void vote(URI var1, ProgressMonitor var2);

    void unvote(URI var1, ProgressMonitor var2);

    void watch(URI var1, ProgressMonitor var2);

    void unwatch(URI var1, ProgressMonitor var2);

    void addWatcher(URI var1, String var2, ProgressMonitor var3);

    void removeWatcher(URI var1, String var2, ProgressMonitor var3);

    void linkIssue(LinkIssuesInput var1, ProgressMonitor var2);

    void addAttachment(ProgressMonitor var1, URI var2, InputStream var3, String var4);

    void addAttachments(ProgressMonitor var1, URI var2, AttachmentInput... var3);

    void addAttachments(ProgressMonitor var1, URI var2, File... var3);

    void addComment(ProgressMonitor var1, URI var2, Comment var3);

    @Beta
    InputStream getAttachment(ProgressMonitor var1, URI var2);

    void addWorklog(URI var1, WorklogInput var2, ProgressMonitor var3);

    public static enum Expandos {
        CHANGELOG,
        SCHEMA,
        NAMES,
        TRANSITIONS;

        private Expandos() {
        }
    }
}

