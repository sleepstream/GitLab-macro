package rest.client;

public interface SessionRestClient {
    Session getCurrentSession(ProgressMonitor var1) throws RestClientException;
}
