package rest.client.internal.jersey;

import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.client.apache.ApacheHttpClient;

import javax.ws.rs.core.UriBuilder;
import java.net.URI;
import java.util.concurrent.Callable;

public class JerseyMetadataRestClient {
    private final String SERVER_INFO_RESOURCE = "/serverInfo";
    private final ServerInfoJsonParser serverInfoJsonParser = new ServerInfoJsonParser();
    private final IssueTypeJsonParser issueTypeJsonParser = new IssueTypeJsonParser();
    private final GenericJsonArrayParser<IssueType> issueTypesJsonParser;
    private final StatusJsonParser statusJsonParser;
    private final PriorityJsonParser priorityJsonParser;
    private final GenericJsonArrayParser<Priority> prioritiesJsonParser;
    private final ResolutionJsonParser resolutionJsonParser;
    private final GenericJsonArrayParser<Resolution> resolutionsJsonParser;
    private final IssueLinkTypesJsonParser issueLinkTypesJsonParser;

    public JerseyMetadataRestClient(URI baseUri, ApacheHttpClient client) {
        super(baseUri, client);
        this.issueTypesJsonParser = GenericJsonArrayParser.create(this.issueTypeJsonParser);
        this.statusJsonParser = new StatusJsonParser();
        this.priorityJsonParser = new PriorityJsonParser();
        this.prioritiesJsonParser = GenericJsonArrayParser.create(this.priorityJsonParser);
        this.resolutionJsonParser = new ResolutionJsonParser();
        this.resolutionsJsonParser = GenericJsonArrayParser.create(this.resolutionJsonParser);
        this.issueLinkTypesJsonParser = new IssueLinkTypesJsonParser();
    }

    public IssueType getIssueType(URI uri, ProgressMonitor progressMonitor) {
        return (IssueType)this.getAndParse(uri, this.issueTypeJsonParser, progressMonitor);
    }

    public Iterable<IssueType> getIssueTypes(ProgressMonitor progressMonitor) {
        URI uri = UriBuilder.fromUri(this.baseUri).path("issuetype").build(new Object[0]);
        return (Iterable)this.getAndParse(uri, this.issueTypesJsonParser, progressMonitor);
    }

    public Iterable<IssuelinksType> getIssueLinkTypes(ProgressMonitor progressMonitor) {
        URI uri = UriBuilder.fromUri(this.baseUri).path("issueLinkType").build(new Object[0]);
        return (Iterable)this.getAndParse(uri, this.issueLinkTypesJsonParser, progressMonitor);
    }

    public Status getStatus(URI uri, ProgressMonitor progressMonitor) {
        return (Status)this.getAndParse(uri, this.statusJsonParser, progressMonitor);
    }

    public Priority getPriority(URI uri, ProgressMonitor progressMonitor) {
        return (Priority)this.getAndParse(uri, this.priorityJsonParser, progressMonitor);
    }

    public Iterable<Priority> getPriorities(ProgressMonitor progressMonitor) {
        URI uri = UriBuilder.fromUri(this.baseUri).path("priority").build(new Object[0]);
        return (Iterable)this.getAndParse(uri, this.prioritiesJsonParser, progressMonitor);
    }

    public Resolution getResolution(URI uri, ProgressMonitor progressMonitor) {
        return (Resolution)this.getAndParse(uri, this.resolutionJsonParser, progressMonitor);
    }

    public Iterable<Resolution> getResolutions(ProgressMonitor progressMonitor) {
        URI uri = UriBuilder.fromUri(this.baseUri).path("resolution").build(new Object[0]);
        return (Iterable)this.getAndParse(uri, this.resolutionsJsonParser, progressMonitor);
    }

    public ServerInfo getServerInfo(ProgressMonitor progressMonitor) {
        return (ServerInfo)this.invoke(new Callable<ServerInfo>() {
            public ServerInfo call() throws Exception {
                WebResource serverInfoResource = JerseyMetadataRestClient.this.client.resource(UriBuilder.fromUri(JerseyMetadataRestClient.this.baseUri).path("/serverInfo").build(new Object[0]));
                return JerseyMetadataRestClient.this.serverInfoJsonParser.parse((JSONObject)serverInfoResource.get(JSONObject.class));
            }
        });
    }
}
