package rest.client.internal.jersey;

import com.sun.jersey.api.client.AsyncViewResource;
import com.sun.jersey.api.client.AsyncWebResource;
import com.sun.jersey.api.client.ViewResource;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.client.apache.ApacheHttpClient;
import com.sun.jersey.client.apache.ApacheHttpClientHandler;
import com.sun.jersey.client.apache.config.DefaultApacheHttpClientConfig;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import rest.client.AuthenticationHandler;

import javax.ws.rs.core.UriBuilder;
import java.net.URI;

public class JerseyYoTrackRestClient {
    private final URI baseUri;
    private final IssueRestClient issueRestClient;
    private final SessionRestClient sessionRestClient;
    private final UserRestClient userRestClient;
    private final ProjectRestClient projectRestClient;
    private final ComponentRestClient componentRestClient;
    private final MetadataRestClient metadataRestClient;
    private final SearchRestClient searchRestClient;
    private final VersionRestClient versionRestClient;
    private final ProjectRolesRestClient projectRolesRestClient;

    public JerseyYoTrackRestClient(URI serverUri, final AuthenticationHandler authenticationHandler) {
        this.baseUri = UriBuilder.fromUri(serverUri).path("/rest/api/latest").build(new Object[0]);
        DefaultApacheHttpClientConfig config = new DefaultApacheHttpClientConfig();
        authenticationHandler.configure(config);
        ApacheHttpClient client = new ApacheHttpClient(createDefaultClientHander(config)) {
            public WebResource resource(URI u) {
                WebResource resource = super.resource(u);
                authenticationHandler.configure(resource, this);
                return resource;
            }

            public AsyncWebResource asyncResource(URI u) {
                AsyncWebResource resource = super.asyncResource(u);
                authenticationHandler.configure(resource, this);
                return resource;
            }

            public ViewResource viewResource(URI u) {
                ViewResource resource = super.viewResource(u);
                authenticationHandler.configure(resource, this);
                return resource;
            }

            public AsyncViewResource asyncViewResource(URI u) {
                AsyncViewResource resource = super.asyncViewResource(u);
                authenticationHandler.configure(resource, this);
                return resource;
            }
        };
        this.metadataRestClient = new JerseyMetadataRestClient(this.baseUri, client);
        this.sessionRestClient = new JerseySessionRestClient(client, serverUri);
        this.issueRestClient = new JerseyIssueRestClient(this.baseUri, client, this.sessionRestClient, this.metadataRestClient);
        this.userRestClient = new JerseyUserRestClient(this.baseUri, client);
        this.projectRestClient = new JerseyProjectRestClient(this.baseUri, client);
        this.componentRestClient = new JerseyComponentRestClient(this.baseUri, client);
        this.searchRestClient = new JerseySearchRestClient(this.baseUri, client);
        this.versionRestClient = new JerseyVersionRestClient(this.baseUri, client);
        this.projectRolesRestClient = new JerseyProjectRolesRestClient(this.baseUri, client, serverUri);
    }

    public IssueRestClient getIssueClient() {
        return this.issueRestClient;
    }

    public SessionRestClient getSessionClient() {
        return this.sessionRestClient;
    }

    public UserRestClient getUserClient() {
        return this.userRestClient;
    }

    public ProjectRestClient getProjectClient() {
        return this.projectRestClient;
    }

    public ComponentRestClient getComponentClient() {
        return this.componentRestClient;
    }

    public MetadataRestClient getMetadataClient() {
        return this.metadataRestClient;
    }

    public SearchRestClient getSearchClient() {
        return this.searchRestClient;
    }

    public VersionRestClient getVersionRestClient() {
        return this.versionRestClient;
    }

    public ProjectRolesRestClient getProjectRolesRestClient() {
        return this.projectRolesRestClient;
    }

    private static ApacheHttpClientHandler createDefaultClientHander(DefaultApacheHttpClientConfig config) {
        HttpClient client = new HttpClient(new MultiThreadedHttpConnectionManager());
        return new ApacheHttpClientHandler(client, config);
    }
}
