package rest.client.internal.jersey;

import rest.client.AuthenticationHandler;
import rest.client.YouTrackRestClient;
import rest.client.YouTrackRestClientFactory;

import java.net.URI;

public class JerseyYouTrackRestClientFactory implements YouTrackRestClientFactory {
    public JerseyYouTrackRestClientFactory() {
    }

    public YouTrackRestClient create(URI serverUri, AuthenticationHandler authenticationHandler) {
        return new JerseyYoTrackRestClient(serverUri, authenticationHandler);
    }

    public JiraRestClient createWithBasicHttpAuthentication(URI serverUri, String username, String password) {
        return this.create(serverUri, new BasicHttpAuthenticationHandler(username, password));
    }
}
