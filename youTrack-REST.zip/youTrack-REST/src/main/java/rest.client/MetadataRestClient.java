package rest.client;

import javax.swing.*;
import java.net.URI;

public interface MetadataRestClient {
    IssueType getIssueType(URI var1, ProgressMonitor var2);

    Iterable<IssueType> getIssueTypes(ProgressMonitor var1);

    Iterable<IssuelinksType> getIssueLinkTypes(ProgressMonitor var1);

    Status getStatus(URI var1, ProgressMonitor var2);

    Priority getPriority(URI var1, ProgressMonitor var2);

    Iterable<Priority> getPriorities(ProgressMonitor var1);

    Resolution getResolution(URI var1, ProgressMonitor var2);

    Iterable<Resolution> getResolutions(ProgressMonitor var1);

    ServerInfo getServerInfo(ProgressMonitor var1);
}
