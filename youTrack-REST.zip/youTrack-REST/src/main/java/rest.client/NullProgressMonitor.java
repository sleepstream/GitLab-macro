package rest.client;

import javax.swing.*;

public class NullProgressMonitor implements ProgressMonitor {
    public NullProgressMonitor() {
    }
}
